﻿var formatDate2 = d3.timeFormat("%Y");

HousingTrend = function (_parentElement, _saData, _nsaData) {

    this.parentElement = _parentElement;

    this.saData = _saData;
    this.nsaData = _nsaData;

    console.log(this.saData);
    console.log(this.nsaData);

    this.handlesSlider = document.getElementById("slider-handles");

    noUiSlider.create(this.handlesSlider, {
        start: [1991, 2018],
        range: {
            'min': 1991,
            'max': 2018
        },
        step: 4,
        connect: true,
        pips: {
            mode: 'steps',
            stepped: true,
            density:4
        }
    });


    this.initVis();
}

HousingTrend.prototype.initVis = function () {
    var vis = this;

    vis.margin = { top: 40, right: 40, bottom: 60, left: 60 };
    vis.width = 1000 - vis.margin.left - vis.margin.right;
    vis.height = 500 - vis.margin.top - vis.margin.bottom;

    vis.svg = d3.select("#housing-crisis").append("svg")
        .attr("width", vis.width + vis.margin.left + vis.margin.right)
        .attr("height", vis.height + vis.margin.top + vis.margin.bottom);

    vis.x = d3.scaleTime().range([0, vis.width]);
    vis.y = d3.scaleLinear().range([vis.height, 0]);

    vis.g = vis.svg.append("g")
        .attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");

    vis.d = vis.svg.append("g")
        .attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");

    vis.xAxisGroup = vis.svg.append("g")
        .attr("class", "x-axis axis");

    vis.yAxisGroup = vis.svg.append("g")
        .attr("class", "y-axis axis");

    vis.updateVisualization();
}

HousingTrend.prototype.updateVisualization = function () {
    var vis = this;

    vis.timeRangePick = vis.handlesSlider.noUiSlider.get();
    vis.lowerRange = Math.round(vis.timeRangePick[0]);
    vis.upperRange = Math.round(vis.timeRangePick[1]);

    vis.selectBoxValue = document.getElementById("crisis");
    vis.selectedChartValue = vis.selectBoxValue.options[vis.selectBoxValue.selectedIndex].value;

    if (vis.selectedChartValue == "sa") {
        vis.filteredData = vis.saData.filter(checkSelection);
    } else {
        vis.filteredData = this.nsaData.filter(checkSelection);
    }


        function checkSelection(data) {
            return formatDate2(data.YEAR) >= vis.lowerRange && formatDate2(data.YEAR) <= vis.upperRange;
        }

        console.log(vis.filteredData);

        vis.filteredData.sort(function (a, b) {
            return a.Date - b.Date;
        });

        console.log(vis.filteredData);

        //Line object.
        vis.lineChart = d3.line()
            .x(function (d) {
                return vis.x(d.YEAR);
            })
            .y(function (d) {
                return vis.y(d.USA);
            });

        //Scale domain and range
        vis.x.domain([
            d3.min(vis.filteredData, function (d) {
                return d.YEAR;
            }),
            d3.max(vis.filteredData, function (d) {
                return d.YEAR;
            })
        ]);

        //x.domain([lowerRange, upperRange]); 
        vis.y.domain([0, d3.max(vis.filteredData, function (d) {
            return d.USA;
        })]);

        //X & y axes configuration, data binding and call to add to DOM.
        vis.xAxis = d3.axisBottom()
            .scale(vis.x)
            .ticks(function (d) {
                return d.YEAR;
            })
            .ticks(5);

        vis.yAxis = d3.axisLeft()
            .scale(vis.y)
            .ticks(function (d) {
                return d.USA;
            })
            .ticks(10);

        vis.svg.select(".y-axis")
            .attr("transform", "translate(60,0)")
            .attr("font-family", "sans-serif")
            .attr("font-size", "8px")
            .call(vis.yAxis);

        vis.svg.select(".x-axis")
            .attr("transform", "translate(60,400)")
            .attr("font-family", "sans-serif")
            .attr("font-size", "8px")
            .call(vis.xAxis);

        vis.group = vis.g.selectAll("path")
            .data([vis.filteredData]);

        vis.group.enter().append("path")
            .merge(vis.group)
            .transition()
            .duration(800)
            .attr("d", vis.lineChart)
            .attr("transform", "translate(20,0)")
            .style("stroke", "black")
            .attr("fill", "none")
            .attr("stroke-width", 1);

        vis.group.exit().remove();

        vis.dotChart = vis.d.selectAll("circle")
            .data(vis.filteredData);

        vis.dotChart.enter().append("circle")
            .merge(vis.dotChart)
            .attr("r", 1)
            .style("fill",
                function (d) {
                    if (d.USA < 200) {
                        return "red";
                    } else if (d.USA > 200) {
                        return "green";
                    }
                })
            .attr("cx", function (d) {
                return vis.x(d.YEAR);
            })
            .attr("cy", function (d) {
                return vis.y(d.USA);
            })
            .attr("transform", "translate(20,0)")
            .on("mouseover",
                function (d) {
                    div.transition()
                        .duration(200)
                        .style("opacity", 1);
                    div.style("display", "inline");
                    div.html(
                        "<div style='background-color:black;border-style: solid; border-width:thin; border-color:gray;'>" +
                        "<strong><span style='color:white;text-transform:capitalize'>" +
                        formatDate2(d.YEAR) +
                        ": " +
                        d.USA +
                        "</span></strong></div>")
                        .style("left", (d3.event.pageX + 10) + "px")
                        .style("top", (d3.event.pageY - 28) + "px");
                })
            .on("mouseout",
                function (d) {
                    div.style("display", "none");
                });

        vis.dotChart.exit().remove();

    // } else if (selectedChartValue == "nsa") {
    //
    //     //console.log(selectedChartValue);
    //
    //     filteredData = this.nsaData.filter(checkSelection2);
    //
    //     function checkSelection2(data) {
    //         return formatDate2(data.YEAR) >= lowerRange && formatDate2(data.YEAR) <= upperRange;
    //     }
    //
    //     filteredData.sort(function (a, b) {
    //         return a.YEAR - b.YEAR;
    //     });
    //
    //     console.log(filteredData);
    //
    //     var lineChart = d3.line()
    //         .x(function (d) { return vis.x(d.YEAR); })
    //         .y(function (d) { return vis.y(d.USA); });
    //
    //     vis.x.domain([
    //         d3.min(filteredData, function (d) { return d.YEAR; }),
    //         d3.max(filteredData, function (d) { return d.YEAR; })
    //     ]);
    //
    //     vis.y.domain([0, d3.max(filteredData, function (d) { return d.USA; })]);
    //
    //     var xAxis = d3.axisBottom()
    //         .scale(vis.x)
    //         .ticks(function (d) {
    //             return d.YEAR;
    //         })
    //         .ticks(5);
    //
    //     var yAxis = d3.axisLeft()
    //         .scale(vis.y)
    //         .ticks(function (d) {
    //             return d.USA;
    //         })
    //         .ticks(10);
    //
    //     vis.svg.select(".y-axis")
    //         .attr("transform", "translate(60,0)")
    //         .attr("font-family", "sans-serif")
    //         .attr("font-size", "8px")
    //         .call(yAxis);
    //
    //     vis.svg.select(".x-axis")
    //         .attr("transform", "translate(60,400)")
    //         .attr("font-family", "sans-serif")
    //         .attr("font-size", "8px")
    //         .call(xAxis);
    //
    //     var group = vis.g.selectAll("path")
    //         .data([filteredData]);
    //
    //     group.enter().append("path")
    //         .merge(group)
    //         .transition()
    //         .duration(800)
    //         .attr("d", lineChart)
    //         .attr("transform", "translate(20,0)")
    //         .style("stroke", "black")
    //         .attr("fill", "none")
    //         .attr("stroke-width", 1);
    //
    //     group.exit().remove();
    //
    //     var dotChart = vis.d.selectAll("circle")
    //         .data(filteredData);
    //
    //     dotChart.enter().append("circle")
    //         .merge(dotChart)
    //         .attr("r", 1)
    //         .style("fill",
    //         function (d) {
    //             if (d.USA < 200) {
    //                 return "red";
    //             } else if (d.USA > 200) {
    //                 return "green";
    //             }
    //         })
    //         .attr("cx", function (d) { return vis.x(d.YEAR); })
    //         .attr("cy", function (d) { return vis.y(d.USA); })
    //         .attr("transform", "translate(20,0)")
    //         .on("mouseover",
    //         function (d) {
    //             div.transition()
    //                 .duration(200)
    //                 .style("opacity", 1);
    //             div.style("display", "inline");
    //             div.html(
    //                 "<div style='background-color:black;border-style: solid; border-width:thin; border-color:gray;'>" +
    //                 "<strong><span style='color:white;text-transform:capitalize'>" +
    //                 formatDate2(d.YEAR) +
    //                 ": " +
    //                 d.USA +
    //                 "</span></strong></div>")
    //                 .style("left", (d3.event.pageX + 10) + "px")
    //                 .style("top", (d3.event.pageY - 28) + "px");
    //         })
    //         .on("mouseout",
    //         function (d) {
    //             div.style("display", "none");
    //         });
    //
    //     dotChart.exit().remove();
    // }
}