
RecessionVis = function(_parentElement, _data, _eventHandler ){
    this.parentElement = _parentElement;
    this.data = _data;
    //this.eventHandler =
    /**/
    this.eventHandler = _eventHandler;

    this.initVis();
}

RecessionVis.prototype.initVis = function(){
    let vis = this;

    vis.svg =  d3.select("#" + vis.parentElement).append("svg")
        .attr("width", 960)
        .attr("height", 500),
        vis.margin = {top: 20, right: 20, bottom: 110, left: 40},
        vis.margin2 = {top: 430, right: 20, bottom: 30, left: 40},
        vis.width = +vis.svg.attr("width") - vis.margin.left - vis.margin.right,
        vis.height = +vis.svg.attr("height") - vis.margin.top - vis.margin.bottom,
        vis.height2 = +vis.svg.attr("height") - vis.margin2.top - vis.margin2.bottom;


    // Scales and axes

    vis.x = d3.scaleTime().range([0, vis.width]);
    vis.x2 = d3.scaleTime().range([0, vis.width]);
    vis.y0 = d3.scaleLinear().range([vis.height, 0]);
    vis.y1 = d3.scaleLinear().range([vis.height, 0]);
    vis.y2 = d3.scaleLinear().range([vis.height2, 0]);

    vis.xAxis = d3.axisBottom(vis.x);
    vis.xAxis2 = d3.axisBottom(vis.x2);
    vis.yAxis = d3.axisLeft(vis.y0);
    vis.yAxis1 = d3.axisRight(vis.y1);



    // Set domains
    vis.x.domain(d3.extent(vis.data, d => { return d.YEAR; }));
    vis.x2.domain(vis.x.domain());
    vis.y0.domain([0, d3.max(vis.data, d => {return Math.max(d.USA);})]);
    vis.y1.domain([0, d3.max(vis.data, d => {return Math.max(d.RATE); })]);
    vis.y2.domain(vis.y0.domain());

    vis.brushed = function () {
        if (d3.event.sourceEvent && d3.event.sourceEvent.type === "zoom") return;
        let s = d3.event.selection || vis.x2.range();
        vis.x.domain(s.map(vis.x2.invert, vis.x2));
        vis.focus.select(".line1").attr("d", vis.priceLine);
        vis.focus.select(".line2").attr ("d", vis.rateLine);
        vis.focus.select(".axis--x").call(vis.xAxis);
        vis.svg.select(".zoom").call(vis.zoom.transform, d3.zoomIdentity
            .scale(vis.width / (s[1] - s[0]))
            .translate(-s[0], 0));
    }

    vis.zoomed = function () {
        if (d3.event.sourceEvent && d3.event.sourceEvent.type === "brush") return;
        let t = d3.event.transform;
        vis.x.domain(t.rescaleX(vis.x2).domain());
        vis.focus.select(".line1").attr("d", vis.priceLine);
        vis.focus.select(".line2").attr("d", vis.rateLine);
        vis.focus.select(".axis--x").call(vis.xAxis);
        vis.context.select(".brush").call(vis.brush.move, vis.x.range().map(t.invertX, t));
    }


    vis.brush = d3.brushX()
        .extent([[0, 0], [vis.width, vis.height2]])
        .on("brush end", vis.brushed);

    vis.zoom = d3.zoom()
        .scaleExtent([1, Infinity])
        .translateExtent([[0, 0], [vis.width, vis.height]])
        .extent([[0, 0], [vis.width, vis.height]])
        .on("zoom", vis.zoomed);

    vis.area2 = d3.area()
        .curve(d3.curveMonotoneX)
        .x(d => { return vis.x2(d.YEAR); })
        .y0(vis.height2)
        .y1(d => { return vis.y2(d.USA); });

    // define the house price line
    vis.priceLine = d3.line()
        .x(d => { return vis.x(d.YEAR); })
        .y(d => { return vis.y0(d.USA); });

    // define the rates line
    vis.rateLine = d3.line()
        .x(d => { return vis.x(d.YEAR); })
        .y(d => { return vis.y1(d.RATE); });

    // SVG clipping path
    vis.svg.append("defs")
        .append("clipPath")
        .attr("id", "clip")
        .append("rect")
        .attr("width", vis.width)
        .attr("height", vis.height);


    // Create ares for focus and context
    vis.focus = vis.svg.append("g")
        .attr("class", "focus")
        .attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");

    vis.context = vis.svg.append("g")
        .attr("class", "context")
        .attr("transform", "translate(" + vis.margin2.left + "," + vis.margin2.top + ")");

    // Add the X axis
    vis.focus.append("g")
        .attr("class", "axis axis--x")
        .attr("transform", "translate(0," + vis.height + ")")
        .call(vis.xAxis)
        .append("text")
        .attr("class", "axis-title")
        // .attr("transform", "rotate(-90)")
        .attr("y", -30).attr("x", vis.width -100)
        .attr("dy", "1.91em")
        .style("text-anchor", "end")
        .attr("fill", "#5D6971")
        .text("(Timeline)");

    // Add the left Y axis
    vis.focus.append("g")
        .attr("class", "axis axis--y")
        .call(vis.yAxis)
        .append("text")
        .attr("class", "axis-title")
        .attr("transform", "rotate(-90)")
        .attr("y", -10).attr("x", -30)
        .attr("dy", "1.91em")
        .style("text-anchor", "end")
        .attr("fill", "#5D6971")
        .text("(Average House Price)");

    // Add the right Y axis
    vis.focus.append("g")
        .attr("class", "axis axisRed")
        .attr("transform", "translate( " + vis.width + ", 0 )")
        .call(vis.yAxis1).append("text")
        .attr("class", "axis-title")
        .attr("transform", "rotate(-90)")
        .attr("y", -30).attr("x", -30)
        .attr("dy", "1.91em")
        .style("text-anchor", "end")
        .attr("fill", "#5D6971")
        .text("(Mortgage Interest Rate)");

    // Path for price line
    vis.focus.append("path")
        .data([vis.data])
        .attr("class", "line1")
        .attr("d", vis.priceLine);

    // Path for the rates line
    vis.focus.append("path")
        .data([vis.data])
        .attr("class", "line2")
        .attr("stroke", "red")
        .attr("d", vis.rateLine);


    vis.context.append("path")
        .datum(vis.data)
        .attr("d", vis.area2)
        .attr("clip-path", "url(#clip)");

    vis.context.append("g")
        .attr("class", "axis axis--x")
        .attr("transform", "translate(0," + vis.height2 + ")")
        .call(vis.xAxis2);

    vis.context.append("g")
        .attr("class", "brush")
        .call(vis.brush).selectAll("rect")
        .attr("y", -6)
        .attr("height", vis.height + 7)
        .call(vis.brush.move, vis.x.range());

    vis.svg.append("rect")
        .attr("class", "zoom")
        .attr("width", vis.width)
        .attr("height", vis.height)
        .attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")")
        .call(vis.zoom);



}

