// Date parser to convert strings to date objects
var parseDate = d3.timeParse("%m/%e/%Y");
var parseYear = d3.timeParse("%Y");
var formatYear = d3.timeFormat("%Y");

// Variables for the visualization instances
var demDataPop, demDataInc, demDataAge;
var studenLoanData = {'series':[]}
var homeAgeData = {};

var allHomeAgeData = [];
var stdDemoHomeData = [];
var totalHomePercentage = [];
var barchart = null;
var sankeyGraph = [];

//Define the div for the tooltip
var ageTooltip = d3.select("body").append("div")
    .attr("class", "tooltip")
    .attr("id", "ageToolTip")
    .style("opacity", 0);


hazemVis();
philVis();
steveVis();
ryanVis();

// Ryan's Visuals
function ryanVis() {


    queue()
        .defer(d3.csv, "data/FRB_G19.csv")
        .defer(d3.csv, "data/home_ownership_by_age.csv")
        .defer(d3.json, "data/sankey.json")
        .await(function(error, frbData,homeData,graph){

            // --> PROCESS DATA
            console.log(error);
            console.log(homeData);

            homeData.forEach(function(d,i){
                if (i==0){
                    return;
                }
                allHomeAgeData.push(d);
                if (i >= homeData.length - 5){
                    stdDemoHomeData.push(d);
                }
                homeAgeData[d["Group"]] = {};
                for (x=2000;x<=2017;x++){
                    homeAgeData[d["Group"]][x.toString()] = {"owned":+d[x + " Owner"],"total":+d[x + " Total"]}
                    if (d["Group"] == "Total"){
                        totalHomePercentage.push({"date":new Date(Date.parse(x)),"value":+(+d[x + " Owner"]/+d[x + " Total"]).toFixed(2)})
                    }
                }
            });

            console.log("cleaned",allHomeAgeData);
            console.log("total",totalHomePercentage);

            frbData.forEach(function(d){
                if (isNaN(Date.parse(d["Series Description"]))){
                    studenLoanData[d["Series Description"]] = d["Student loans owned and securitized, not seasonally adjusted level"];
                }else{
                    if (!isNaN(d["Student loans owned and securitized, not seasonally adjusted level"]) && d["Student loans owned and securitized, not seasonally adjusted level"] != "") {
                        studenLoanData['series'].push({
                            "date": new Date(Date.parse(d["Series Description"])),
                            "value": +d["Student loans owned and securitized, not seasonally adjusted level"]
                        })
                    }
                }
            });

            sankeyGraph = graph;

            console.log("student",studenLoanData);
            createRyanVis();
        });
}

function updateBarchart(year){
    console.log(year);
    barchart.year = year;
    barchart.updateVis();
}

function createRyanVis(){
    linechart = new LineChart("line-chart2",totalHomePercentage);
    barchart = new StackedBarChart("bar-chart",stdDemoHomeData);
    areachart = new AreaChart("area-chart",studenLoanData["series"]);
    sankeychart = new SankeyChart("sankey-chart",sankeyGraph);

}

// Steve's visuals

var hpiLineChart;

function steveVis() {
    queue()
        .defer(d3.csv, "data/hpi_sa.csv")
        .defer(d3.csv, "data/hpi_nsa.csv")
        .await(wrangleHousingData);
}

function wrangleHousingData(error, sa, nsa) {
    if (!error) {

        var parseDate2 = d3.timeParse("%m/%d/%Y");


        sa.forEach(function (d) {
            d.YEAR = parseDate2(d.YEAR);

            d.USA = +d.USA;
            d.USA = Math.round(d.USA);
        });

        nsa.forEach(function (d) {
            d.YEAR = parseDate2(d.YEAR);

            d.USA = +d.USA;
            d.USA = Math.round(d.USA);
        });

        saData = sa;
        nsaData = nsa;

        console.log(saData);
        console.log(nsaData);

        hpiLineChart = new HousingTrend("housing-crisis", saData, nsaData);
    }
}

function updateSteveVisualization() {
    hpiLineChart.updateVisualization();
}


// Hazem Visual
function hazemVis() {

    d3.csv("./data/data5.csv", function(error, data) {
        if (error) throw error;

        data.forEach(function (d) {
            d.YEAR = new Date(d.YEAR);
            d.USA = +d.USA;
            d.RATE = +d.RATE;
        });
        let recessionVis = new RecessionVis('line-chart', data);
    });
}


// Phil's Visuals

function philVis() {
    queue()
        .defer(d3.csv, "./data/income.csv") //income growth rates, 1970 - 2017
        .defer(d3.csv,"./data/age.csv") //populations of age groups and sex, 2010 - 2017
        .await(wrangleData);
}

function wrangleData(error, income, age) {
    if(!error){
        income.forEach(function(d){
            d.Year = parseDate(d.Year);
            d.realIncPC = +d.realIncPC; //real income per capita growth rate
            d.incPC = +d.incPC; //income per capita growth rate
            d.medInc = +d.medInc; //median income growth rate
        });

        age.forEach(function(d){
            d.Year = formatYear(parseYear(d.Year));
            d.Population = +d.Population;
        });

        age = d3.nest()
        //.key(function(d) { return d.Type; })
            .key(function(d) { return d.Year; })
            .key(function(d) { return d.Age; })
            .entries(age);

        //assign global variables
        demDataInc = income;
        demDataAge = age;

        //create the visualizations
        createVis();
    }
}

function createVis() {
    var chartInc = new ChartIncome("chartIncome", demDataInc);
    var chartAge = new ChartAge("chartAge", demDataAge);
}
