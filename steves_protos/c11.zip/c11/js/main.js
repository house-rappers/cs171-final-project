// Date parser to convert strings to date objects
var parseDate = d3.timeParse("%m/%e/%Y");
var parseYear = d3.timeParse("%Y");
var formatYear = d3.timeFormat("%Y");

// Variables for the visualization instances
var demDataPop, demDataInc, demDataAge;

//Define the div for the tooltip
var ageTooltip = d3.select("body").append("div")
    .attr("class", "tooltip")
    .attr("id", "ageToolTip")
    .style("opacity", 0);

hazemVis();
philVis();
steveVis(); 

function steveVis() {

    queue()
        .defer(d3.csv, "data/hpi_sa.csv")
        .defer(d3.csv, "data/hpi_nsa.csv")
        .await(wrangleHousingData);
}

function wrangleHousingData(error, sa, nsa) {
    if (!error) {

        var parseDate2 = d3.timeParse("%m/%d/%Y");


        sa.forEach(function (d) {
            d.YEAR = parseDate2(d.YEAR);

            d.USA = +d.USA;
            d.USA = Math.round(d.USA);
        });

        nsa.forEach(function (d) {
            d.YEAR = parseDate2(d.YEAR);

            d.USA = +d.USA;
            d.USA = Math.round(d.USA);
        });

        saData = sa;
        nsaData = nsa;

        console.log(saData);
        console.log(nsaData); 

        var hpiLineChart = new HousingTrend("housing-crisis", saData, nsaData); 
    }
}

function hazemVis() {

    d3.csv("./data/data5.csv", function(error, data) {
        if (error) throw error;

        data.forEach(function (d) {
            d.YEAR = new Date(d.YEAR);
            d.USA = +d.USA;
            d.RATE = +d.RATE;
        });
        let recessionVis = new RecessionVis('line-chart', data);
    });
}


function philVis() {
    queue()
        .defer(d3.csv, "./data/income.csv") //income growth rates, 1970 - 2017
        .defer(d3.csv,"./data/age.csv") //populations of age groups and sex, 2010 - 2017
        .await(wrangleData);
}

function wrangleData(error, income, age) {
    if(!error){
        income.forEach(function(d){
            d.Year = parseDate(d.Year);
            d.realIncPC = +d.realIncPC; //real income per capita growth rate
            d.incPC = +d.incPC; //income per capita growth rate
            d.medInc = +d.medInc; //median income growth rate
        });

        age.forEach(function(d){
            d.Year = formatYear(parseYear(d.Year));
            d.Population = +d.Population;
        });

        age = d3.nest()
        //.key(function(d) { return d.Type; })
            .key(function(d) { return d.Year; })
            .key(function(d) { return d.Age; })
            .entries(age);

        //assign global variables
        demDataInc = income;
        demDataAge = age;

        //create the visualizations
        createVis();
    }
}

function createVis() {
    var chartInc = new ChartIncome("chartIncome", demDataInc);
    var chartAge = new ChartAge("chartAge", demDataAge);
}
